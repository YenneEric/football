﻿DROP TABLE IF EXISTS Person.PersonAddress;
DROP TABLE IF EXISTS Person.AddressType;
DROP TABLE IF EXISTS Person.Person;
