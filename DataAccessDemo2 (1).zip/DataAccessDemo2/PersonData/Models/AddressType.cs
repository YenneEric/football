﻿namespace PersonData.Models
{
   public enum AddressType
   {
      Home = 1,
      Work = 2,
      School = 3,
      Other = 4
   }
}
